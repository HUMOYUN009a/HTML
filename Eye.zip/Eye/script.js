let icon = document.querySelector("i");
let input = document.querySelector("input");

icon.addEventListener("click", function(){
    if(input.type == "password"){
        input.type = "text"
        this.classList.remove("fa-eye-slash")
        this.classList.add("fa-eye")
    }else{
        input.type = "password"
        this.classList.add("fa-eye-slash")
        this.classList.remove("fa-eye")
    }
})